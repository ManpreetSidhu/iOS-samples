//
//  ViewController.h
//  Assignment2
//
//  Created by Student on 2017-02-13.
//  Copyright © 2017 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *start;

@property (weak, nonatomic) IBOutlet UIButton *stop;
@property (weak, nonatomic) IBOutlet UILabel *time;
@property double intialsalary;
@property (weak, nonatomic) IBOutlet UISlider *slider;
@property (weak, nonatomic) IBOutlet UILabel *salary;
@property (weak, nonatomic) IBOutlet UILabel *mylabel;
@property double cost_m;
@property double slider_value;

- (IBAction)startbtn:(id)sender;
- (IBAction)stopbtn:(id)sender;

@end

