//
//  ViewController.m
//  Assignment2
//
//  Created by Student on 2017-02-13.
//  Copyright © 2017 Student. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

NSTimer *t;
NSUserDefaults *preferences;

NSString *position=@"position";
NSString *timet=@"timet";
UIColor *orangecolor;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor  colorWithRed:238/255.0f green:224/255.0f blue:229/255.0f alpha:1.0f];
    
    _mylabel.textColor=[UIColor  colorWithRed:220/255.0f green:20/255.0f blue:60/255.0f alpha:1.0f];
    _cost_m = 0.00;
    _intialsalary=0;
    _slider_value = _slider.value;
   
   preferences = [NSUserDefaults standardUserDefaults];
    
    
    
   if ([preferences objectForKey:position] == nil)
    {
        
    }
    else
    {
        _slider.value = [preferences doubleForKey:position];
         //_cost_m = [preferences doubleForKey:timet];
        
        _salary.text=[NSString stringWithFormat:@"$%0.6f",_intialsalary];
        
        _time.text= [NSString stringWithFormat:@"%0.2f",_cost_m];
        
    }
    
    

}
- (IBAction)incomechange:(id)sender {
    _slider_value = _slider.value;
}

- (void)onTick:(NSTimer *)timer{
    _cost_m +=0.01;
    _intialsalary +=_slider_value/(365*24*60*60);
    
    
    _salary.text=[NSString stringWithFormat:@"$%0.6f",_intialsalary];
    
    _time.text= [NSString stringWithFormat:@"%0.2f",_cost_m];
   [preferences setDouble:_intialsalary forKey:position];
    [preferences setDouble:_cost_m forKey:timet];
    
  [preferences synchronize];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)startbtn:(id)sender {
    t = [NSTimer scheduledTimerWithTimeInterval:1.0
                                         target:self
                                       selector:@selector(onTick:)
                                       userInfo:nil
                                        repeats:YES];
    

    
}

- (IBAction)stopbtn:(id)sender {
    if(t)
    {
        [t invalidate];
        t=nil;
    }
}
@end
