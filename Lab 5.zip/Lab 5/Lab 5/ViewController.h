//
//  ViewController.h
//  Lab 5
//
//  Created by Student on 2017-03-21.
//  Copyright © 2017 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>


@property (weak, nonatomic) IBOutlet UITextField *name;
@property (weak, nonatomic) IBOutlet UITextField *time;
@property (weak, nonatomic) IBOutlet UITextField *location;
@property (weak, nonatomic) IBOutlet UITextField *comment;
@property (weak, nonatomic) IBOutlet UIButton *savebutton;
- (IBAction)Savedata:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *InfoTable;




@property (nonatomic, retain, readonly) NSManagedObjectModel *managedObjectModel; 

@property (nonatomic, retain, readonly) NSManagedObjectContext *managedObjectContext;  // Get insert delete from the databse

@property (nonatomic, retain, readonly) NSPersistentStoreCoordinator *persistentStoreCoordinator;  // Database connection

- (NSURL *)applicationDocumentsDirectory;


@end

