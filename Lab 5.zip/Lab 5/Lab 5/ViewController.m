//
//  ViewController.m
//  Lab 5
//
//  Created by Student on 2017-03-21.
//  Copyright © 2017 Student. All rights reserved.
//

#import "ViewController.h"
#import <CoreData/CoreData.h>
#import "Pokeman+CoreDataClass.h"

NSArray *results;

@interface ViewController ()

@end

@implementation ViewController

@synthesize managedObjectContext = _managedObjectContext;               // Get, insert, delete.

@synthesize managedObjectModel = _managedObjectModel;                   // Schema

@synthesize persistentStoreCoordinator = _persistentStoreCoordinator;   // Database connection




- (void)saveContext{
    
    NSError *error = nil;
    
    NSManagedObjectContext *managedObjectContext = self.managedObjectContext;
    
    if (managedObjectContext != nil) {
        
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error]) {
            
            NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
            
            abort();
            
        }
        
    }
    
}


- (NSManagedObjectContext *)managedObjectContext{
    
    if (_managedObjectContext != nil) {
        
        return _managedObjectContext;
        
    }
    
    
    
    NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
    
    if (coordinator != nil) {
        
    
        _managedObjectContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSMainQueueConcurrencyType];
        [_managedObjectContext setPersistentStoreCoordinator:coordinator];
        
        
    }
    
    return _managedObjectContext;
    
}


- (NSManagedObjectModel *)managedObjectModel{
    
    if (_managedObjectModel != nil) {
        
        return _managedObjectModel;
        
    }
    
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"Lab_5" withExtension:@"momd"];
    
    NSLog(@"%@", modelURL);
    _managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    
    return _managedObjectModel;
    
}


- (NSPersistentStoreCoordinator *)persistentStoreCoordinator

{
    
    if (_persistentStoreCoordinator != nil) {
        
        return _persistentStoreCoordinator;
        
    }
    
    
    
    NSURL *storeURL = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"ModelCoreData.sqlite"];
    
    NSLog(@"%@", storeURL);
    
    NSError *error = nil;
    
    _persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self managedObjectModel]];
    
    if (![_persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error]) {
        
        
        
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        
        abort();
        
    }
    
    
    
    return _persistentStoreCoordinator;
    
}


#pragma mark - Application's Documents directory


// Returns the URL to the application's Documents directory.

- (NSURL *)applicationDocumentsDirectory{
    
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
    
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [results count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Number of rows is the number of time zones in the region for the specified section.
  
    return 1;
}





- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *MyIdentifier = @"cellinfo";
    UITableViewCell *cell = [_InfoTable dequeueReusableCellWithIdentifier:MyIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault  reuseIdentifier:MyIdentifier];
    }
    Pokeman *p=[results objectAtIndex:indexPath.row];
    cell.textLabel.text = p.name;
    cell.textLabel.text=p.location;
    return cell;
}


// END CORE DATA //
- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSManagedObjectContext *context = [self managedObjectContext];
    NSError *error = nil;
    _InfoTable.delegate=self;
    _InfoTable.dataSource=self;
    
    NSFetchRequest *request = [[NSFetchRequest alloc]init];
    [request setEntity:[NSEntityDescription entityForName:@"Pokeman" inManagedObjectContext:context]];
    results = [context executeFetchRequest:request error:&error];
    if(error){
        NSLog(@"Coudn't fetch %@",[error localizedDescription]);
        
        }
    
    if([results count]>0)
    {
            for(Pokeman *e in results)
            {
                NSLog(@"%@", e.name);
                NSLog(@"%@", e.location);
                NSLog(@"%@", e.time);
                NSLog(@"%@", e.comments);
                
            }
    }
}

    // Do any additional setup after loading the view, typically from a nib.



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)Savedata:(id)sender {
    
    NSString* name=_name.text;
    NSString* time=_time.text;
    NSString* location=_location.text;
    NSString* comments=_comment.text;
    
    NSManagedObjectContext *context = [self managedObjectContext];
    NSError *error;
    
    Pokeman *e =[NSEntityDescription
                insertNewObjectForEntityForName:@"Pokeman" inManagedObjectContext:context];
    
    [e setValue:comments forKey:@"comments"];
    [e setValue:location forKey:@"location"];
    [e setValue:name forKey:@"name"];
    [e setValue:time forKey:@"time"];
    
    if(![context save:&error]){
        NSLog(@"coudn't save , %@",[error localizedDescription]);
    
    }
}
@end
