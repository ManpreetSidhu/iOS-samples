//
//  Pokeman+CoreDataClass.h
//  Lab 5
//
//  Created by Student on 2017-03-21.
//  Copyright © 2017 Student. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface Pokeman : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Pokeman+CoreDataProperties.h"
