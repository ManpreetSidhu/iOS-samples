//
//  Pokeman+CoreDataClass.m
//  Lab 5
//
//  Created by Student on 2017-03-21.
//  Copyright © 2017 Student. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import "Pokeman+CoreDataClass.h"

@implementation Pokeman

@end
