//
//  Pokeman+CoreDataProperties.m
//  Lab 5
//
//  Created by Student on 2017-03-21.
//  Copyright © 2017 Student. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import "Pokeman+CoreDataProperties.h"

@implementation Pokeman (CoreDataProperties)

+ (NSFetchRequest<Pokeman *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"Pokeman"];
}

@dynamic name;
@dynamic time;
@dynamic location;
@dynamic comments;

@end
