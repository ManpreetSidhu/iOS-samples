//
//  ViewController.m
//  lab12
//
//  Created by Student on 2017-03-30.
//  Copyright © 2017 Student. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)Takepicture:(id)sender {
    UIImagePickerController *picker=[[UIImagePickerController alloc]
                                     init];
    picker.delegate=self;
    picker.allowsEditing=YES;
    
#if TARGET_IPHONE_SIMULATOR
    picker.sourceType =UIImagePickerControllerSourceTypePhotoLibrary;
# elif TARGET_OS_IPHONE
    picker.sourceType=UIImagePickerControllerSourceTypeCamera;
#endif
    
    [self presentViewController:picker animated:YES completion:nil];
}

-(void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    UIImage *img=info[UIImagePickerControllerEditedImage];
    self.imgview.image= img;
    [picker dismissViewControllerAnimated:YES completion:nil];
}
@end
